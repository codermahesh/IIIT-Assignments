#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>


int main()
{
	 
	char tablefile[]="c1>=c2";
	char *token;
	
	int i;
	
	enum OpType{ NO_OP,ASSIGNMENT,LESS,GREATER,LESS_EQUAL,GREATER_EQUAL};
	enum OpType optype=NO_OP;
	i=0;
	while(tablefile[i]!='\0')
	{
			switch(tablefile[i])
			{
					case '=':
						if(optype==NO_OP)
							optype=ASSIGNMENT;
						else if(optype==LESS)
						{
							optype=LESS_EQUAL;printf("<=");
							break;
						}
						else
						{
							optype=GREATER_EQUAL;printf(">=");
							break;	
						}	
					
					break;
					case '>':
							optype=GREATER;
							printf(">");
					break;
					case '<':
							optype=LESS;
							printf("<");
					break;
			}	
			i++;
	}
	
	token= strtok(tablefile,"=><");
	
	printf("1: %s" ,token);
	
	
	token =strtok(NULL,"=");
	printf("2:%s",token);
	return 0;
}
