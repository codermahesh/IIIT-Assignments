Checks Performed
1. NO table
2. NO attribute
3. Malformed query


valid queries

1.select * from airports
2.select id,name from airports
3.select * from airports where latitude>40
4.select * from airports where id=6524
5.select * from airports where longitude<60
6.select * from airports,countries where name=code
7.select distinct name from airports


Output:

New file is created with specified name
<control does not return to console>



