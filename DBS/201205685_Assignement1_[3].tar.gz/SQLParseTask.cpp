#include<stdio.h>
#include<string.h>
#include<set>
#include<string>
#include<iostream>
#include "CustomError.cpp"

#define COLUMNLIST 0
#define TABLELIST 1
#define CONDITION 2
#define OUTPUT 3

enum STATUS { 
		FAILURE=0,
		SUCCESS
};
enum OpType{ 
		NO_OP,
		ASSIGNMENT,
		LESS,GREATER,
		LESS_EQUAL,
		GREATER_EQUAL
};



enum OpType optype=NO_OP;

char *tokenlist[4];			/* holds raw query tokens*/

char *RequestTable[2];		/* Points to names of requested table*/

char *RequestColumn[20];    /* Points tpo name of reuqested columns*/
int RequestColumnNo[20];

int RequestTableLength;		/*Track of request tables*/
int RequestColumnLength;     /*Track of reuqested Column*/
int RequestDistinct;		/* Specifies fields characheristics*/
char *ConditionOn[2];

void JoinExecute()
{
		int fd=-1;
		int nread;
		char tablefile1[20]="";
		char tablefile2[20]="";
		char line1[256],line2[256];
		
		char token1[MAX_STRLEN],token2[MAX_STRLEN];	
		int tokenlength1,tokenlength2;
		
		int n_token1,n_token2;
		char columnvalue1[20],columnvalue2[20];
		
		char buffer1[1],buffer2[1];
		int current_out = dup(1);
		 
		
		strcat(tablefile1,RequestTable[0]);
		strcat(tablefile2,RequestTable[1]);
		
		strcat(tablefile1,".csv");
		strcat(tablefile2,".csv");
		
		size_t filedescriptor1 = open(tablefile1,O_RDONLY);
		size_t filedescriptor2 = open(tablefile2,O_RDONLY);
		
	if(filedescriptor1 < 0 && filedescriptor2 < 0)
	{
			printf("Error In Reading Table Files\n");
			exit(EXIT_SUCCESS);
	}
	else
	{
		/*OUTPUT REDIRECTIONS*/
		if(tokenlist[OUTPUT]!=NULL)
		{
				 fd = open(tokenlist[OUTPUT], O_CREAT|O_RDWR, 0666);
				 if(fd==-1)
				 {
						perror("COULD NOT CREATE FILE ..!\n");
						exit(EXIT_SUCCESS);
				 }
				 dup2(fd,1);
				 
					
		}

		tokenlength1=0;
		line1[0]='\0';
		columnvalue1[0]='\0';
		n_token1=0;
		
		 
		while((nread=read(filedescriptor1,buffer1,sizeof(buffer1))) >0)
		{	
				if(buffer1[0]==',')
				{
					token1[tokenlength1]='\0';					
					tokenlength1=0;
					n_token1++;
					
					if(n_token1==6)
					{	
						strcpy(columnvalue1,token1);
						//printf("cpied %d %s;",n_token1,columnvalue1);	
					}
					
					strcat(line1," ");
					strcat(line1,token1);
					//printf("%s\n",line1);
					 
				}
				else if(buffer1[0]=='"')
				{
					
				}
				else if(buffer1[0]=='\n')
				{
					tokenlength2=0;
					line2[0]='\0';
					n_token2=0;
					columnvalue2[0]='\0';
					
					//printf("FOR TOKEN:%s",columnvalue1);
					lseek(filedescriptor2,0,SEEK_SET);
					while((nread=read(filedescriptor2,buffer2,sizeof(buffer2))) >0)
					{
						if(buffer2[0]==',')
						{
							token2[tokenlength2]='\0';
							tokenlength2=0;
							n_token2++;	
							if(n_token2==2)
							{	
								strcpy(columnvalue2,token2);	
							}
							
							if(n_token2!=2)
								strcat(line2,token2);
							strcat(line2," ");	
							//printf("%s\n",line2);	
						}
						else if(buffer2[0]=='"')
						{
					
						}
						else if(buffer2[0]=='\n')
						{
							//printf(":::%s %s:::\n",columnvalue1,columnvalue2);	
							if(strcmp(columnvalue1,columnvalue2)==0)
							{
								printf("%s %s\n",line1,line2);
							}
							n_token2=0;
							tokenlength2=0;
							line2[0]='\0'; 
						}
						else
						{
							token2[tokenlength2++]=buffer2[0];
						}
					}
					n_token1=0;
					tokenlength1=0;
					line1[0]='\0'; 
				}
				else
				{
					token1[tokenlength1++]=buffer1[0];
				}			
 
		}
		if(fd!=-1)
		{
			dup2(current_out, 1);
			close(1);
			close(fd);
			
		}	
			
	}
}
int searchfield(int inparam)
{
	int j,k;
	
		for(j=0;j<=NoOfSchemaTables;j++)
		{
			for(k=0;k<=schemaTableList[j].NoOfFields;k++)
			{
				//printf("*%s*%s*",RequestColumn[i],schemaTableList[j].columnlist[k].t_attribute);
				if(strcmp(ConditionOn[inparam],schemaTableList[j].columnlist[k].t_attribute)==0)
				{
					return k; 
					 
				}
			}
			 
		}
		
		return -1;		
}
int searchRequestedColumn(int inparam)
{
	int j,k;
	
		for(j=0;j<=NoOfSchemaTables;j++)
		{
			for(k=0;k<=schemaTableList[j].NoOfFields;k++)
			{
				//printf("*%s*%s*",RequestColumn[i],schemaTableList[j].columnlist[k].t_attribute);
				if(strcmp(RequestColumn[inparam],schemaTableList[j].columnlist[k].t_attribute)==0)
				{
					return k; 
					 
				}
			}
			 
		}
		
		return -1;		
}
void conditionExecution()
{
		char line1[256];
		char token1[MAX_STRLEN];
		int tokenlength1;
		int fd=-1;
		int n_token1;
		char columnvalue1[20];
		char buffer1[1];
		int nread;
		int stopcolumn;
		
		int columntoInt=0;
		int valuetoInt=0;
		
		char tablefile1[20]="";
		strcat(tablefile1,RequestTable[0]);
		strcat(tablefile1,".csv");
		size_t filedescriptor1 = open(tablefile1,O_RDONLY);
		
		
		stopcolumn=searchfield(0);
		if(stopcolumn==-1)
		{
				query_syntax_error(ATTR_NOT_FOUND);
				return;
		}
		if(filedescriptor1 < 0)
		{
			printf("Error In Reading Table Files\n");
			exit(EXIT_SUCCESS);		
		}
		else
		{
				/*OUTPUT REDIRECTIONS*/
				if(tokenlist[OUTPUT]!=NULL)
				{
					fd = open(tokenlist[OUTPUT], O_CREAT|O_RDWR, 0666);
					if(fd==-1)
					{
						perror("COULD NOT CREATE FILE ..!\n");
						exit(EXIT_SUCCESS);
					}
					dup2(fd,1);
				 
					
				}

				tokenlength1=0;
				line1[0]='\0';
				columnvalue1[0]='\0';
				n_token1=0;
				
				 
				while((nread=read(filedescriptor1,buffer1,sizeof(buffer1))) >0)
				{	
					if(buffer1[0]==',')
					{
						token1[tokenlength1]='\0';					
						tokenlength1=0;
						n_token1++;
						 
						if( (n_token1-1)==stopcolumn)
						{
								strcpy(columnvalue1,token1);
								//printf("INTO :%s %d\n",token1,stopcolumn);
						}
						
						strcat(line1," ");
						strcat(line1,token1);
					}
					else if(buffer1[0]=='"')
					{
					
					}
					else if(buffer1[0]=='\n')
					{
						//printf("OPT:%d",optype);
						switch(optype)
						{
							case ASSIGNMENT:
							//printf("COMPARE:%s %s+\n",ConditionOn[1],columnvalue1);
							if(strcmp(ConditionOn[1],columnvalue1)==0)
							{
									printf("%s \n",line1);
							}	
							break;
							case LESS:
							columntoInt=atoi(columnvalue1);
							valuetoInt=atoi(ConditionOn[1]);
							//printf("COMPARE : %d %d\n",columntoInt,valuetoInt);
							if(columntoInt < valuetoInt)
							{
								printf("%s \n",line1);
							}
							break;
							case GREATER:
							columntoInt=atoi(columnvalue1);
							valuetoInt=atoi(ConditionOn[1]);
							//printf("COMPARE : %d %d\n",columntoInt,valuetoInt);
							if(columntoInt > valuetoInt)
							{
								printf("%s \n",line1);
							}
							
							break;
							case GREATER_EQUAL:
							//printf("OPT:%d\n",optype);	
							//resetspace(ConditionOn[1]);
							columntoInt=atoi(columnvalue1);
							valuetoInt=atoi(ConditionOn[1]);
							//printf("COMPARE:%s+%s+\n",ConditionOn[1],columnvalue1);
							//printf("COMPARE : +%d+%d+\n",columntoInt,valuetoInt);
							if(columntoInt >= valuetoInt)
							{
								printf("%s \n",line1);
							}

							break;
							case LESS_EQUAL:
							columntoInt=atoi(columnvalue1);
							valuetoInt=atoi(ConditionOn[1]);
							//printf("COMPARE : %d %d\n",columntoInt,valuetoInt);
							if(columntoInt <= valuetoInt)
							{
								printf("%s \n",line1);
							}

							break;
							
							case NO_OP: 
							break;
						}
						n_token1=0;
						tokenlength1=0;
						line1[0]='\0'; 
					}
					else
					{
						token1[tokenlength1++]=buffer1[0];
					}	
				}	
		 
		/*check presence of column*/
		/* get column no*
		 */
	 }
}
void distinctExecution()
{
	using namespace std;
		
		int stopcolumn;
		char tablefile[20]="";

		char buffer[1];
		int nread;			/* number of bytes read*/
	
		char token[MAX_STRLEN];	
		int tokenlength;
		int n_token;
		int k;
		int fd=-1;
		int limit=0;
		int current_out = dup(1);
		 
		set<string> myset;
		set<string>::iterator it;
		
		printf(" %s\n",RequestColumn[0]);
		stopcolumn=searchRequestedColumn(0);
		
		strcat(tablefile,RequestTable[0]);
		strcat(tablefile,".csv");
		size_t filedescriptor = open(tablefile,O_RDONLY);
		
		if(filedescriptor < 0)
		{
			printf("Error In Reading Table File\n");
			exit(EXIT_SUCCESS);
		}
		else
		{
			if(tokenlist[OUTPUT]!=NULL)
			{
				 fd = open(tokenlist[OUTPUT], O_CREAT|O_RDWR,0666);
				 if(fd==-1)
				 {
						perror("COULD NOT CREATE FILE ..!\n");
						exit(EXIT_SUCCESS);
				 }
				 dup2(fd,1);
				 
				 		
			}
			tokenlength=0;
			n_token=-1;	
			//printf("check 1");
			while((nread=read(filedescriptor,buffer,sizeof(buffer))) >0)
			{
				if(buffer[0]==',')
				{
					token[tokenlength]='\0';					
					tokenlength=0;
					n_token++;
					for(k=0;k<=RequestColumnLength;k++)
					{
						if(n_token==stopcolumn && limit!=0)
						{
							//printf(" %s \t",token);
							myset.insert(string(token));
						}	
					}
				}
				else if(buffer[0]=='"')
				{
				}
				else if(buffer[0]=='\n')
				{
					printf("\n");
					limit=1;
					n_token=-1;
					tokenlength=0;
				}
				else
				{
					token[tokenlength++]=buffer[0];
				}			
		}
		
		for (it=myset.begin(); it!=myset.end(); ++it)
			std::cout<<*it<<"\n";
	}
	
	if(fd!=-1)
	{
			close(1);
			close(fd);
			dup2(current_out, 1);
	}
}
void SingleExecute()
{
	 
	char tablefile[20]="";
	
	char buffer[1];
	int nread;			/* number of bytes read*/
	
	char token[MAX_STRLEN];	
	int tokenlength;
	int n_token;
	int fd=-1;				/*Output file descriptor*/
	int k;
	
	int current_out = dup(1);
	 
	strcat(tablefile,RequestTable[0]);
	strcat(tablefile,".csv");
	//printf("Open:(%s)\n",tablefile);
	
	size_t filedescriptor = open(tablefile,O_RDONLY);
	
	if(filedescriptor < 0)
	{
			printf("Error In Reading Table File\n");
			exit(EXIT_SUCCESS);
	}
	else
	{
			if(tokenlist[OUTPUT]!=NULL)
			{
				 fd = open(tokenlist[OUTPUT], O_CREAT|O_RDWR,0666);
				 if(fd==-1)
				 {
						perror("COULD NOT CREATE FILE ..!\n");
						exit(EXIT_SUCCESS);
				 }
				 dup2(fd,1);
				 
				 		
			}
			//printf("A\n");
				/*	Distinct*/
			if(RequestDistinct==1)
			{
				distinctExecution();
				return; 
			}
			//printf("A\n");
			if(tokenlist[CONDITION]!=NULL)
			{
				conditionExecution();
				close(filedescriptor);
	
				if(fd!=-1)
				{
					close(1);
					close(fd);
				}	
				return;	
			}
			
			
			tokenlength=0;
			n_token=-1;	
			 
			while((nread=read(filedescriptor,buffer,sizeof(buffer))) >0)
			{
				if(buffer[0]==',')
				{
					token[tokenlength]='\0';					
					tokenlength=0;
					n_token++;
					for(k=0;k<=RequestColumnLength;k++)
					{
						if(n_token==RequestColumnNo[k])
						{
							printf(" %s \t",token);
						}	
					}
				}
				else if(buffer[0]=='"')
				{
				}
				else if(buffer[0]=='\n')
				{
					printf("\n");
					n_token=-1;
					tokenlength=0;
				 

				}
				else
				{
					token[tokenlength++]=buffer[0];
				}	
			}	
	}
	close(filedescriptor);
	
	if(fd!=-1)
	{
			close(1);
			close(fd);
			dup2(current_out, 1);
	}
	
	/*	
	for(i=0;i<=RequestColumnLength;i++)
	{
			printf("  $%d$",RequestColumnNo[i]);
			
	}*/
	
}
void SQLExecute()
{
		 
		/*ONE TABLE*/
		switch(RequestTableLength)
		{
				case 0:
						SingleExecute();
				break;
				
				case 1:
						JoinExecute();
				break;
				
		}
		/*TWO TABLE*/
}

/*************************** New Query Inints *****************/
void newQueryInits()
{
	int i;
	
	for(i=0;i<4;i++)
	{
		tokenlist[i]=NULL;
	}
	RequestColumnLength=NOT_DEFINED;
	RequestTableLength=NOT_DEFINED;
	optype=NO_OP;
	RequestDistinct=0;
}
/****************************** Parsing ***************************/
void resetspace(char *string)
{
	int i=0;
		while(string[i]!='\0')
		{
			if(string[i]=='\n')
			   string[i]='\0';
			i++;   	
		}
}

int typeCheck()
{
	int i,j,k;
	int found; 
	int singlefieldflag;
	/*Check for valid tables*/
	
	for(i=0;i<=RequestTableLength;i++)
	{
			found=1;
			for(j=0;j<=NoOfSchemaTables;j++)
			{
				resetspace(RequestTable[i]);
				//printf(" %s %d %s %d\n",RequestTable[i],strlen(RequestTable[i]),schemaTableList[j].t_name,strlen(schemaTableList[j].t_name));
				if(strcmp(RequestTable[i],schemaTableList[j].t_name)==0)
				{
					found=0;
					break;	
				}
			}
			if(found==1)
			{
				//printf("NOT FOUND\n");
					query_syntax_error(TABLE_NOT_FOUND);
				return FAILURE;
			}
	}
	
	

	/* request all columns*/
	
	if(strcmp(RequestColumn[0],"*")==0)
	{
					
		for(j=0;j<=NoOfSchemaTables;j++)
		{
			if(strcmp(schemaTableList[j].t_name,RequestTable[0])==0)
			{
				for(k=0;k<=schemaTableList[j].NoOfFields;k++)
				{
					RequestColumnNo[k]=k;
					RequestColumnLength++;
				}
				//printf("Collen:%d\n",RequestColumnLength);
				break;
			}
		}
	   return SUCCESS;
	}
	
		
	for(i=0;i<=RequestColumnLength;i++)
	{
		singlefieldflag=1;
		
		resetspace(RequestColumn[i]);
	//	printf("Check for  %d %s %d\n",i,RequestColumn[i],strlen(RequestColumn[i]));
		
		for(j=0;j<=NoOfSchemaTables;j++)
		{
			for(k=0;k<=schemaTableList[j].NoOfFields;k++)
			{
				//printf("*%s*%s*",RequestColumn[i],schemaTableList[j].columnlist[k].t_attribute);
				if(strcmp(RequestColumn[i],schemaTableList[j].columnlist[k].t_attribute)==0)
				{
					singlefieldflag=0;
					RequestColumnNo[i]=k;
					//printf("FOUND\n");
					break;
				}
			}
			if(singlefieldflag==0)
			{
				//printf("TABLE SKIP\n");
				break;
			}
		}
		
		if(singlefieldflag==1)
		{
				//printf("NOPE\n");
				query_syntax_error(ATTR_NOT_FOUND);
				return FAILURE;
		}
					
	} 
	return SUCCESS;
	
}


void setOutput(const char* token)
{
		//printf("Output:%s\n ",token);
}

void retrieveConditions(char * condition)
{
		/* Codition Format*/
		/*		<colmun>  <op> <value>	
		 * 		<column>  <op> <column>
		 * 		<op>  = > < >= <=
		  */
		 int i; 
		 char * token;
		 
		 if(condition==NULL) return;
		 
		 //printf(" start Cond: %s\n",condition);
		 i=0;
		 while(condition[i]!='\0')
		 {
			 switch(condition[i])
			{
					case '=':
						if(optype==NO_OP)
							optype=ASSIGNMENT;
						else if(optype==LESS)
						{
							optype=LESS_EQUAL;//printf("<=");
							break;
						}
						else
						{
							optype=GREATER_EQUAL;//printf(">=");
							break;	
						}	
					
					break;
					case '>':
							optype=GREATER;
							//printf(">");
					break;
					case '<':
							optype=LESS;
							//printf("<");
					break;
			}	
			i++;
			 
		 } 
		 token= strtok(condition,"=><");
		 ConditionOn[0]=token;
		 token =strtok(NULL," ");
		 ConditionOn[1]=token;
		 resetspace(ConditionOn[1]);
		 //printf("<<<%s=%s>>>",ConditionOn[0],ConditionOn[1]);	
} 
void retrieveColumnList(char * columnList)
{
	/*Column Format*/
		/*
		 * 		* for all
		 * 		col1,col2 list specified
		 * 		TABLE.col list specified
		 * 		distinct col
		 */	
		 char * token;
		  
		 //printf("COL-LIST:%s\n",columnList);
		 token = strtok(columnList,",");
		 
		 while(token!=NULL)
		 {
			RequestColumn[++RequestColumnLength]=token;
			token=strtok(NULL,",");
		 }
/*			
		 for(i=0;i<=RequestColumnLength;i++)
		 {
			printf("COL %d %s \n",i,RequestColumn[i]);	
		 }
		 */ 
}

void retrieveTableList(char * tableList)
{
	/*Table list*/
	/*		table1			-single table
	 * 		table1,table2	-join	
	 */	
		char * token;
		 
		
		//printf("Table-LIST:%s\n",tableList);
		token=strtok(tableList,",");
		
		 while(token!=NULL)
		 {
			RequestTable[++RequestTableLength]=token;
			token=strtok(NULL,",");
		 }
		 //printf("DET LENG:%d",RequestTableLength);
/*		 for(i=0;i<=RequestTableLength;i++)
		 {
			printf("TABLE %d %s \n",i,RequestTable[i]);	
		 } */
}

int tokeniser(char *sqlcmd)
{
	
	/* QUERY Format*/
	/*	SELECT   * | <COL> LIST
	 * 	FROM  	 TABLE LIST
	 * 	[WHERE   CONDITION TYPES];		
	 * 
	 * */
	 
	
  //char sentence []="select c1,c2,c3 from t1,t1";
  //char sentence []="select c1,c2,c3 from t1,t1 | filename";
  //char sentence []="select c1,c2,c3 from t1,t1 where cond>=cond";
  //char sentence []="select c1,c2,c3 from t1,t1 where cond>=cond | filename";
  char *token;
 
  

  newQueryInits();	
  
  //token=strtok(sentence," ");
  token=strtok(sqlcmd," "); 
  if(strcmp(token,"select")==0) 
  {	 
		token = strtok(NULL," ");
		if(token!=NULL)
		{
			
			if(strcmp(token,"distinct")==0)
			{	// select distinct
					
					token = strtok(NULL," ");
					if(token==NULL)
					{
						
						query_syntax_error(QUERY_MALFORM);
						return FAILURE;	
					}
					RequestDistinct=1;	
					//printf("dis:%d\n",RequestDistinct);
			}
			
			tokenlist[COLUMNLIST]=token;
			token = strtok(NULL," ");
			if(token==NULL)
			{
				//select distinct/all c1,c2 
				/*ERROR QUERY*/
				query_syntax_error(QUERY_MALFORM);
				return FAILURE;
			}
			else if(strcmp(token,"from")==0) 
			{
				//select c1,c2 from 
				
				token = strtok(NULL," ");
				if(token!=NULL)
				{
					//select c1,c2 from t1,t2
					tokenlist[TABLELIST]=token;
					token=strtok(NULL," ");
					if(token==NULL)
					{
						tokenlist[CONDITION]=NULL;
						tokenlist[OUTPUT]=NULL;
					}
					else if(strcmp(token,"where")==0)
					{
						//select c1,c2 from t1,t2 where
						token = strtok(NULL," ");
						if(token!=NULL)
						{
							////select c1,c2 from t1,t2 where c>c	
							tokenlist[CONDITION]=token;
							token = strtok(NULL," ");
							if(token==NULL)
							{
								//printf("NULL CHECK");
								//select c1,c2 from t1,t2 where
								tokenlist[OUTPUT]=NULL;
							}
							else if(strcmp(token,"|")==0)
							{
								//select c1,c2 from t1,t2 where |
								token = strtok(NULL," ");
								if(token==NULL)
								{
									/*ERROR*/
									query_syntax_error(QUERY_MALFORM);
									return FAILURE;
								}
								else
								{
									//select c1,c2 from t1,t2 where | filename
									tokenlist[OUTPUT]=token;
								}
							}
							else
							{
									/*ERROR*/
									query_syntax_error(QUERY_MALFORM);
									return FAILURE;
							}
						}
						else
						{
							/*ERROR QUERY*/
							query_syntax_error(QUERY_MALFORM);
							return FAILURE;
						}
					}
					else if(strcmp(token,"|")==0)
					{
						//printf("FGHFGh");
						token = strtok(NULL," ");
						if(token!=NULL)
						{
							tokenlist[OUTPUT]=token;
						}
						else
						{
							/*ERROR QUERY*/
							query_syntax_error(QUERY_MALFORM);
							return FAILURE;
						}
					}
					else
					{
						/*ERROR QUERY*/
						query_syntax_error(QUERY_MALFORM);
						return FAILURE;
					}
				}
				else
				{
					/*ERROR QUERY*/
					query_syntax_error(QUERY_MALFORM);
					return FAILURE;
				}	
				
			}
			else
			{
				// select c1,c2 blah
				query_syntax_error(QUERY_MALFORM);
				return FAILURE;
			}
			
		}
		else
		{
			/*ERROR*/  // only select 
			query_syntax_error(QUERY_MALFORM);
			return FAILURE;
		}
  }
  else
  {
		/*ERROR*/  // not select 
		query_syntax_error(QUERY_MALFORM);
		return FAILURE;
  }
  
 /* 		
  for (i=0;i<4;i++)
  {
		if(tokenlist[i]!=NULL)
		printf("--%i %s \n",i,tokenlist[i]);
  }
 */
	retrieveTableList(tokenlist[TABLELIST]);
	retrieveColumnList(tokenlist[COLUMNLIST]);
	retrieveConditions(tokenlist[CONDITION]);
	
	/*REDIRECTION TO FILE*/
	/*
		sqlcmd | outputfile
	 */	

	return SUCCESS;
}
