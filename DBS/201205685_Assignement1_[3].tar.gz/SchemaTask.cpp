#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>

#define MAX_FIELDS 10
#define MAX_STRLEN 32
#define NOT_DEFINED -1



/* Default Schema File name*/
char schemafile[]="megatron05685.schema";

/*************************** Enumeration ***************************/

enum SchemaStructure{
		TABLE,
		ATTRIBUTE,
		TYPE
};

enum FieldType{
		INTEGER,
		STRING
};

/*************************** Data Structs ***************************/

struct Field{
		char t_attribute[MAX_STRLEN];
		enum FieldType t_type;
};

struct SchemaTable{
		char t_name[MAX_STRLEN];	/*stores table name*/
		struct Field columnlist[MAX_FIELDS];
		int NoOfFields;
};

int NoOfSchemaTables;

/* Maintains tables to be handle as arraylist*/
struct SchemaTable schemaTableList[2];


/*a*/
void printSchema()
{
	int i,j;
	
	for(i=0;i<=NoOfSchemaTables;i++)
	{
			printf("\nTABLE NAME:%s\n",schemaTableList[i].t_name);
			for(j=0;j<=schemaTableList[i].NoOfFields;j++)
			{
					printf("<%s,%d>\t",
								schemaTableList[i].columnlist[j].
								t_attribute,
								schemaTableList[i].columnlist[j].
								t_type

					);
			}
	}
	
}
/* Function:	reads db metadat from file
 * Auxilary:    stores data in structs specified as globals 
 * */

void dbGetSchema()
{
	char buffer[1];		/* Single char read buffer*/
	int nread;			/* number of bytes read*/
				
	char token[MAX_STRLEN];	
	int tokenlength;	 /*tracks length of working string */
	
	
	
	enum SchemaStructure tokenExpectation;

	/*Retrieving Schema*/
	
	size_t filedescriptor = open(schemafile,O_RDONLY);
		
	if(filedescriptor < 0)
	{
			printf("Error In Reading Schema File\n");
			exit(EXIT_SUCCESS);
	}
	else
	{
			/*Couting number of tables -- as no of lines*/
			printf("SCHEMA FILE PROCESSING..");
			

			tokenlength=0;
			tokenExpectation=TABLE;
			
			NoOfSchemaTables=NOT_DEFINED;
			schemaTableList[0].NoOfFields=NOT_DEFINED;	
			schemaTableList[1].NoOfFields=NOT_DEFINED;
			
			
			while((nread=read(filedescriptor,buffer,sizeof(buffer))) >0)
			{
				//printf(" %c ",buffer[0]);
				if(buffer[0]=='#')			/*End of Token*/
				{
					
     				token[tokenlength]='\0';					
					tokenlength=0;
					
					
					switch(tokenExpectation)
					{
						case TABLE:
							//printf("TABLE: %s \n",token);
							NoOfSchemaTables++;
							tokenExpectation=ATTRIBUTE;
							strcpy(schemaTableList[NoOfSchemaTables].t_name,token);
						break;
						case ATTRIBUTE:							
							//printf("COL:%s \t",token);
							tokenExpectation=TYPE;
							schemaTableList[NoOfSchemaTables].NoOfFields++;	
							
							strcpy(
							schemaTableList[NoOfSchemaTables].columnlist[
							schemaTableList[NoOfSchemaTables].NoOfFields].
							t_attribute,token
							);
							
						break;
						case TYPE:
							//printf("TYP: %s\n",token);
							tokenExpectation=ATTRIBUTE;
							if(strcmp(token,"int")==0)
							{
								schemaTableList[NoOfSchemaTables].columnlist[
								schemaTableList[NoOfSchemaTables].NoOfFields].
								t_type=INTEGER;
							}
							else
							{
								schemaTableList[NoOfSchemaTables].columnlist[
								schemaTableList[NoOfSchemaTables].NoOfFields].
								t_type=STRING;
							}
							
						break;
					}
					
				}
				else if(buffer[0]=='\n')	/*New Table Expected*/
				{
					//printf("\n");	
					tokenExpectation=TABLE;
				}
				else
				{
					token[tokenlength++]=buffer[0];
				}
				
			}	
	}
	
//	printSchema();

}

