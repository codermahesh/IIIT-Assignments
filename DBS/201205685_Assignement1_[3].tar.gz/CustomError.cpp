#include<errno.h>
#include<stdio.h>

/*Function: Displays Error in input Query
 * 
 * */
enum ErrorSet{
		QUERY_MALFORM,
		TABLE_NOT_FOUND,
		ATTR_NOT_FOUND
			
}; 
void query_syntax_error(enum ErrorSet errorid)
{
		switch(errorid)
		{
			case QUERY_MALFORM:
				printf("CHECK QUERY SYNTAX .. !\n");	
			break;
			case TABLE_NOT_FOUND:
				printf("TABLE NOT FOUND .. !\n");	
			break;
			case ATTR_NOT_FOUND:
				printf("ATTRIBUTE NOT FOUND .. !\n");	
			break;			 	
		}
	
}
/* Function : Displays extenal errors 
 * 
 * */
void instant_error()
{
		if(errno!=0)
		{
			printf("Error No: %d\n",errno);
			printf("Error description is : %s\n",strerror(errno));
		}
}
