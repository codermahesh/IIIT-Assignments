/*
*	Author : Mahesh Attarde	 IIIT hyderabad
*	 		Database Engine (simulating Megatron 2000)
*/
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>

#include "SchemaTask.cpp"
#include "SQLParseTask.cpp"

#define SQL_LENGHT 256

/********************************* DB engine  starts here**********************/

int main(int argc, char* argv[])
{
	//char sqlcmd[SQL_LENGHT];	/*sql cmd line*/
	
	size_t sqllen=SQL_LENGHT;
	char *sqlcmd=NULL;
		
	/*prompt for sql cmd*/
	printf("\t*** DBMS Engine ***\n");
	
	/***** prerequisite *****/
	
	/* retriving db schema from file*/
	dbGetSchema();
	
	do{
	
		printf("\nMegatron05685 $");
		//scanf("%[ \t\n]",sqlcmd);	/*scanset to surpress whitespace*/
		
		getline(&sqlcmd,&sqllen,stdin);
		fflush(stdin); 

		if(tokeniser(sqlcmd));
		{
				/*Query Processing*/
				if(typeCheck())
					SQLExecute(); 
		}
		
	}while(1);

	return 0;
}

